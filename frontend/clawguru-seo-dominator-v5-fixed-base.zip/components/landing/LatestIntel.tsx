"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type IntelItem = {
  slug: string;
  title: string;
  summary: string;
  severity: "SAFE" | "WARNING" | "CRITICAL";
  publishedAt: string;
};

type IntelDoc = {
  generatedAt: string;
  items: IntelItem[];
};

function badge(sev: IntelItem["severity"]) {
  if (sev === "CRITICAL") return "text-cyber-red border-red-500/25 shadow-danger";
  if (sev === "WARNING") return "text-cyber-muted border-cyber-border";
  return "text-cyber-green border-cyber-green/25 shadow-glow";
}

export function LatestIntel() {
  const [doc, setDoc] = useState<IntelDoc | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/intel")
      .then((r) => r.json())
      .then((j) => alive && setDoc(j))
      .catch(() => alive && setDoc(null));
    return () => {
      alive = false;
    };
  }, []);

  const items = (doc?.items ?? []).slice(0, 6);

  return (
    <section className="rounded-2xl border border-cyber-border bg-cyber-panel/55 p-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Daily Intel</div>
          <h2 className="mt-2 text-2xl font-semibold text-cyber-ink">Fresh hardening signals (auto-updated)</h2>
          <p className="mt-2 text-sm text-cyber-muted">
            Generated daily via scheduled job. Use this as a “what to fix next” queue.
          </p>
        </div>
        <div className="text-xs text-cyber-muted">
          {doc?.generatedAt ? <>Updated: <span className="font-mono text-cyber-ink">{new Date(doc.generatedAt).toISOString()}</span></> : "Loading…"}
        </div>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2">
        {items.length ? (
          items.map((it) => (
            <div key={it.slug} className="rounded-xl border border-cyber-border bg-black/30 p-4 hover:bg-black/45 transition">
              <div className="flex items-center justify-between gap-3">
                <div className="text-sm font-semibold text-cyber-ink">{it.title}</div>
                <div className={`rounded-lg border px-2 py-1 text-xs font-mono ${badge(it.severity)}`}>{it.severity}</div>
              </div>
              <div className="mt-2 text-sm text-cyber-muted">{it.summary}</div>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs text-cyber-muted">Published: <span className="font-mono text-cyber-ink">{it.publishedAt}</span></span>
                <Link href="/tools" className="text-xs font-semibold text-cyber-green hover:underline">
                  Run audit →
                </Link>
              </div>
            </div>
          ))
        ) : (
          <div className="text-sm text-cyber-muted">
            Intel stream unavailable. Your site is still fine — scheduled intel populates on published deploys.
          </div>
        )}
      </div>
    </section>
  );
}
