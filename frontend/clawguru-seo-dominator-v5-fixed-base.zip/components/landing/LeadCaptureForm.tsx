"use client";

import { useState } from "react";

export function LeadCaptureForm() {
  const [email, setEmail] = useState("");
  const [ok, setOk] = useState<null | boolean>(null);

  return (
    <div className="rounded-2xl border border-cyber-border bg-cyber-panel/55 p-5">
      <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Operator Updates</div>
      <div className="mt-2 text-lg font-semibold text-cyber-ink">
        Get new hardening patches & incident playbooks
      </div>
      <p className="mt-2 text-sm text-cyber-muted">
        Short, actionable. No fluff. Email only when there’s something worth deploying.
      </p>

      {/* Netlify Forms */}
      <form
        name="clawguru-ops-updates"
        method="POST"
        action="/thanks"
        data-netlify="true"
        netlify-honeypot="bot-field"
        className="mt-4 flex flex-col gap-3 sm:flex-row"
        onSubmit={() => setOk(true)}
      >
        <input type="hidden" name="form-name" value="clawguru-ops-updates" />
        <p className="hidden">
          <label>
            Don’t fill this out: <input name="bot-field" />
          </label>
        </p>

        <input
          className="w-full flex-1 rounded-xl border border-cyber-border bg-black/35 px-4 py-3 text-sm text-cyber-ink placeholder:text-cyber-muted focus:outline-none focus:ring-2 focus:ring-cyber-green/30"
          type="email"
          name="email"
          required
          value={email}
          placeholder="you@domain.com"
          onChange={(e) => setEmail(e.target.value)}
        />
        <button
          type="submit"
          className="rounded-xl border border-cyber-green/35 bg-black/45 px-5 py-3 text-sm font-semibold text-cyber-green hover:bg-black/60"
        >
          Get Updates
        </button>
      </form>

      <div className="mt-3 text-xs text-cyber-muted">
        By subscribing you agree to receive operational security updates. Unsubscribe anytime.
      </div>

      {/* Static hidden form for Netlify build bots */}
      <form name="clawguru-ops-updates" data-netlify="true" hidden>
        <input type="text" name="email" />
      </form>

      {ok && (
        <div className="mt-4 rounded-xl border border-cyber-green/25 bg-black/30 px-4 py-3 text-sm text-cyber-muted">
          Subscribed. If you don’t get redirected, the form still captured—Netlify can be slow to show submissions.
        </div>
      )}
    </div>
  );
}
