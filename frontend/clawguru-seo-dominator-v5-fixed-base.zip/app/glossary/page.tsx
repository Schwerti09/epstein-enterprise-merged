import Link from "next/link";
import { Breadcrumbs } from "@/components/seo/Breadcrumbs";
import { Schema } from "@/components/seo/Schema";
import { GLOSSARY } from "@/lib/pseo";

export const revalidate = 86400;

export default function GlossaryPage() {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || "https://clawguru.org").replace(/\/$/, "");
  const url = `${base}/glossary`;

  const schema = {
    "@context":"https://schema.org",
    "@type":"WebPage",
    name:"ClawGuru Security Glossary",
    description:"Definitions of common security terms used in OpenClaw hardening runbooks.",
    url,
    publisher:{ "@type":"Organization", name:"ClawGuru" }
  };

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <Schema json={schema} />
      <Breadcrumbs items={[{ href: "/", label: "Dashboard" }, { href: "/glossary", label: "Glossary" }]} />

      <div className="mt-4 rounded-2xl border border-cyber-border bg-cyber-panel/55 p-6">
        <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Reference</div>
        <h1 className="mt-2 text-3xl font-semibold">Security Glossary</h1>
        <p className="mt-3 text-cyber-muted max-w-3xl">
          Short, operator-focused definitions. This is written for people who run agents and don’t want their servers to become science projects.
        </p>

        <div className="mt-6 grid gap-4">
          {GLOSSARY.map((t) => (
            <section key={t.slug} id={t.slug} className="rounded-2xl border border-cyber-border bg-black/25 p-5">
              <h2 className="text-xl font-semibold">{t.term}</h2>
              <p className="mt-2 text-cyber-muted">{t.short}</p>
              <p className="mt-3 text-sm text-cyber-muted">{t.long}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-sm">
                <Link className="rounded-xl border border-cyber-border bg-black/25 px-3 py-2 hover:bg-black/40" href="/runbooks">
                  See related runbooks
                </Link>
                <Link className="rounded-xl border border-cyber-green/30 bg-black/30 px-3 py-2 text-cyber-green hover:bg-black/45" href="/pricing">
                  Get Hardening Kit
                </Link>
              </div>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
