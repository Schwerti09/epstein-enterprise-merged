import Link from "next/link";
import { Breadcrumbs } from "@/components/seo/Breadcrumbs";
import { Schema } from "@/components/seo/Schema";
import { comparePairs } from "@/lib/pseo";

export const revalidate = 86400;

export default function CompareIndex() {
  const pairs = comparePairs();

  const base = (process.env.NEXT_PUBLIC_SITE_URL || "https://clawguru.org").replace(/\/$/, "");
  const url = `${base}/compare`;

  const schema = {
    "@context":"https://schema.org",
    "@type":"CollectionPage",
    name:"ClawGuru Security Comparisons",
    description:"Operator-grade comparisons for infrastructure and hardening stacks used with OpenClaw.",
    url,
    publisher:{ "@type":"Organization", name:"ClawGuru" }
  };

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <Schema json={schema} />
      <Breadcrumbs items={[{ href: "/", label: "Dashboard" }, { href: "/compare", label: "Compare" }]} />

      <div className="mt-4 rounded-2xl border border-cyber-border bg-cyber-panel/55 p-6">
        <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Decision support</div>
        <h1 className="mt-2 text-3xl font-semibold">Certified Comparisons</h1>
        <p className="mt-3 text-cyber-muted max-w-3xl">
          Pick the option that reduces exposure and keeps your control plane private. These are pragmatic, security-first comparisons.
        </p>

        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {pairs.map((p) => (
            <Link key={p.slug} href={`/compare/${p.slug}`} className="rounded-2xl border border-cyber-border bg-black/25 p-4 hover:bg-black/40">
              <div className="font-mono text-xs text-cyber-muted uppercase">{p.kind}</div>
              <div className="mt-1 text-lg font-semibold">{p.a} vs {p.b}</div>
              <div className="mt-1 text-sm text-cyber-muted">Hardening posture, isolation, defaults, and operator ergonomics.</div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}
