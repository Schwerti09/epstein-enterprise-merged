import Link from "next/link";
import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/seo/Breadcrumbs";
import { Schema } from "@/components/seo/Schema";
import { PROVIDERS, STACKS, titleCase } from "@/lib/pseo";

export const revalidate = 86400;

export async function generateStaticParams() {
  // pre-render the most likely comparisons (small, safe)
  const seeds = [
    "aws-vs-hetzner",
    "aws-vs-cloudflare",
    "gcp-vs-azure",
    "ubuntu-vs-debian",
    "iptables-vs-nftables",
    "docker-vs-kubernetes",
  ];
  return seeds.map((slug) => ({ slug }));
}

function parse(slug: string) {
  const m = slug.match(/^([a-z0-9-]+)-vs-([a-z0-9-]+)$/);
  if (!m) return null;
  const a = m[1], b = m[2];
  const providerA = PROVIDERS.includes(a);
  const providerB = PROVIDERS.includes(b);
  const stackA = STACKS.includes(a);
  const stackB = STACKS.includes(b);

  if (providerA && providerB) return { kind: "provider" as const, a, b };
  if (stackA && stackB) return { kind: "stack" as const, a, b };
  return null;
}

export default function ComparePage({ params }: { params: { slug: string } }) {
  const meta = parse(params.slug);
  if (!meta) return notFound();

  const aT = titleCase(meta.a);
  const bT = titleCase(meta.b);

  const base = (process.env.NEXT_PUBLIC_SITE_URL || "https://clawguru.org").replace(/\/$/, "");
  const url = `${base}/compare/${params.slug}`;

  const schema = {
    "@context":"https://schema.org",
    "@type":"Article",
    headline: `${aT} vs ${bT} — security hardening comparison`,
    dateModified: new Date().toISOString().slice(0,10),
    mainEntityOfPage: url,
    author: { "@type":"Organization", name:"ClawGuru" },
    publisher: { "@type":"Organization", name:"ClawGuru" },
  };

  const rows = meta.kind === "provider"
    ? [
        { k: "Private networking", a: "Depends on VPC/VNet hygiene", b: "Strong if you enforce private defaults" },
        { k: "Firewall ergonomics", a: "Powerful, complex", b: "Often simpler, fewer foot-guns" },
        { k: "Blast radius controls", a: "Excellent with discipline", b: "Excellent with discipline" },
        { k: "Operator overhead", a: "High (many knobs)", b: "Medium (fewer knobs)" },
      ]
    : [
        { k: "Default hardening", a: "Good baselines", b: "Good baselines" },
        { k: "Firewall control", a: "Classic rules; easy to foot-gun", b: "Cleaner model; easier to audit" },
        { k: "Service isolation", a: "Depends on config", b: "Depends on config" },
        { k: "Operator ergonomics", a: "Familiar", b: "More modern" },
      ];

  const faq = {
    "@context":"https://schema.org",
    "@type":"FAQPage",
    mainEntity: [
      { "@type":"Question", name:`Which is safer for OpenClaw control plane: ${aT} or ${bT}?`, acceptedAnswer:{"@type":"Answer", text:"Both can be safe if you enforce private access, strict auth, and default-deny egress. The dangerous option is the one you expose publicly and never audit."}},
      { "@type":"Question", name:"What’s the fastest win?", acceptedAnswer:{"@type":"Answer", text:"Put the control plane behind a VPN/allowlist, restrict egress, and run agents with least privilege. Then add logging for anomalies."}},
    ]
  };

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <Schema json={schema} />
      <Schema json={faq} />

      <Breadcrumbs
        items={[
          { href: "/", label: "Dashboard" },
          { href: "/compare", label: "Compare" },
          { href: `/compare/${params.slug}`, label: `${aT} vs ${bT}` },
        ]}
      />

      <div className="mt-4 rounded-2xl border border-cyber-border bg-cyber-panel/55 p-6">
        <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Comparison</div>
        <h1 className="mt-2 text-3xl font-semibold">{aT} vs {bT}</h1>
        <p className="mt-3 text-cyber-muted max-w-3xl">
          Security-first comparison focused on exposure reduction, operator safety, and hardened defaults.
        </p>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full min-w-[760px] border-separate border-spacing-0">
            <thead>
              <tr className="text-left text-xs tracking-[0.14em] uppercase text-cyber-muted">
                <th className="border-b border-cyber-border pb-3 pr-4">Area</th>
                <th className="border-b border-cyber-border pb-3 pr-4">{aT}</th>
                <th className="border-b border-cyber-border pb-3">{bT}</th>
              </tr>
            </thead>
            <tbody className="text-sm text-cyber-ink">
              {rows.map((r) => (
                <tr key={r.k} className="align-top">
                  <td className="border-b border-cyber-border py-4 pr-4 font-semibold">{r.k}</td>
                  <td className="border-b border-cyber-border py-4 pr-4 text-cyber-muted">{r.a}</td>
                  <td className="border-b border-cyber-border py-4 text-cyber-muted">{r.b}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-8 grid gap-3 md:grid-cols-2">
          <Link className="rounded-xl border border-cyber-green/30 bg-black/35 px-4 py-3 font-semibold text-cyber-green hover:bg-black/55" href="/pricing">
            Download Hardening Kit
          </Link>
          <Link className="rounded-xl border border-cyber-border bg-black/25 px-4 py-3 font-semibold hover:bg-black/40" href="/tools">
            Run Live Audit
          </Link>
        </div>

        <div className="mt-6 text-sm text-cyber-muted">
          Rule of thumb: the safe choice is the one you can keep private, audit continuously, and operate without shortcuts.
        </div>
      </div>
    </main>
  );
}
