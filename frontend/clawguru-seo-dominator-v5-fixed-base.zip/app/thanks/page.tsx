import Link from "next/link";

export default function ThanksPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <div className="rounded-2xl border border-cyber-border bg-cyber-panel/60 p-6">
        <div className="text-xs tracking-[0.18em] text-cyber-muted uppercase">Subscription Confirmed</div>
        <h1 className="mt-2 text-3xl font-semibold text-cyber-ink">You’re on the Ops Updates list.</h1>
        <p className="mt-4 text-cyber-muted">
          You’ll get short, actionable hardening patches and incident playbooks.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/tools" className="rounded-xl border border-cyber-green/35 bg-black/45 px-5 py-3 font-semibold text-cyber-green hover:bg-black/60">
            Run Live Audit
          </Link>
          <Link href="/pricing" className="rounded-xl border border-cyber-border bg-black/25 px-5 py-3 font-semibold text-cyber-ink hover:bg-black/40">
            Get Pro Kits
          </Link>
        </div>
      </div>
    </main>
  );
}
