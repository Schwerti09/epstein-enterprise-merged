import { NextResponse } from "next/server";
import { generateText, getAIConfig } from "@/lib/ai";
import { parseCookie, verifyAccess } from "@/lib/access";
import { checkAndBumpRateLimit, type RateTier } from "@/lib/ratelimit";
import { getCachedAIResponse, setCachedAIResponse } from "@/lib/aiCache";

export const runtime = "nodejs";

function getClientIp(req: Request) {
  const xf = req.headers.get("x-forwarded-for");
  if (xf) return xf.split(",")[0].trim();
  const xnf = req.headers.get("x-nf-client-connection-ip");
  if (xnf) return xnf.trim();
  return "unknown";
}

function tierFromPayload(payload: Record<string, unknown> | null): RateTier {
  const t = String(payload?.tier || "").toLowerCase();
  if (t === "team" || t === "teams") return "team";
  if (t === "pro") return "pro";
  if (t === "daypass") return "daypass";

  // Back-compat: old cookies only had mode
  const mode = String(payload?.mode || "").toLowerCase();
  if (mode === "payment") return "daypass";
  if (mode === "subscription") return "pro";
  return "free";
}

export async function POST(req: Request) {
  const secret = process.env.ACCESS_TOKEN_SECRET || "";
  if (!secret) return NextResponse.json({ error: "ACCESS_TOKEN_SECRET missing" }, { status: 500 });

  const cookies = parseCookie(req.headers.get("cookie"));
  const token = cookies["cg_access"];
  if (!token) return NextResponse.json({ error: "ACCESS_REQUIRED" }, { status: 401 });

  const payload = verifyAccess(token, secret);
  if (!payload) return NextResponse.json({ error: "ACCESS_INVALID" }, { status: 401 });

  // Expiry check (ms timestamp)
  const exp = Number((payload as any).exp || 0);
  if (!exp || Date.now() > exp) return NextResponse.json({ error: "ACCESS_EXPIRED" }, { status: 401 });

  const tier = tierFromPayload(payload);
  const ip = getClientIp(req);

  // Rate-limit before spending tokens
  const rlKey = `${ip}:${String((payload as any).sid || "na")}`;
  const rl = await checkAndBumpRateLimit({ key: rlKey, tier });

  if (!rl.allowed) {
    return NextResponse.json(
      { error: "RATE_LIMIT", tier, resetSeconds: rl.resetSeconds },
      { status: 429, headers: { "Retry-After": String(rl.resetSeconds) } }
    );
  }

  const body = await req.json().catch(() => ({}));
  const prompt = String(body?.prompt || "").slice(0, 50_000);
  if (!prompt) return NextResponse.json({ error: "prompt required" }, { status: 400 });

  const system = String(
    body?.system ||
      "You are ClawGuru, an institutional-grade cybersecurity assistant for OpenClaw operators. Be concrete, structured, and action-oriented."
  ).slice(0, 20_000);

  const { provider, model } = getAIConfig();

  // Cache hit?
  const cached = await getCachedAIResponse({ provider, model, system, prompt });
  if (cached.hit) {
    return NextResponse.json({
      ok: true,
      cached: true,
      provider,
      model,
      text: cached.text,
      rateLimit: { remaining: rl.remaining, resetSeconds: rl.resetSeconds, tier },
    });
  }

  const result = await generateText({ prompt, system, maxOutputTokens: 900 });

  // Cache it (best-effort)
  await setCachedAIResponse({ provider: result.provider, model: result.model, system, prompt, text: result.text }).catch(() => {});

  return NextResponse.json({
    ok: true,
    cached: false,
    ...result,
    rateLimit: { remaining: rl.remaining, resetSeconds: rl.resetSeconds, tier },
  });
}
