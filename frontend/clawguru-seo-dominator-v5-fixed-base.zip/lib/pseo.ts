export const TOPICS = ["rce-hardening", "openclaw-security", "agent-sandboxing", "firewall-baselines", "zero-trust", "ssh-lockdown", "container-escape", "supply-chain", "secrets-management", "telemetry", "incident-response", "patch-management"];
export const PROVIDERS = ["aws", "gcp", "azure", "hetzner", "digitalocean", "ovh", "linode", "vultr", "cloudflare", "oracle", "scaleway", "ionos"];
export const VECTORS = ["reverse-shell", "cmd-injection", "deserialization", "ssrf", "path-traversal", "lfi", "rfi", "priv-esc", "token-theft", "webhook-abuse", "config-drift", "open-ports"];
export const STACKS = ["ubuntu", "debian", "alpine", "docker", "kubernetes", "nginx", "caddy", "traefik", "systemd", "ufw", "iptables", "nftables"];

export function getRunbookCount(): number {
  const n = Number(process.env.PSEO_RUNBOOK_COUNT || "10000");
  return Number.isFinite(n) ? Math.max(1000, Math.min(200000, Math.floor(n))) : 10000;
}

function pick<T>(arr: T[], idx: number): T {
  return arr[idx % arr.length];
}

export function runbookSlugById(id: number): string {
  const a = pick(TOPICS, id);
  const b = pick(PROVIDERS, id * 7 + 3);
  const c = pick(VECTORS, id * 13 + 5);
  const d = pick(STACKS, id * 17 + 11);
  return `openclaw-${a}-${b}-${c}-${d}-${id}`;
}

export function parseRunbookSlug(slug: string): { id: number, topic: string, provider: string, vector: string, stack: string } | null {
  const m = slug.match(/-(\d+)$/);
  if (!m) return null;
  const id = Number(m[1]);
  if (!Number.isFinite(id)) return null;
  const topic = pick(TOPICS, id);
  const provider = pick(PROVIDERS, id * 7 + 3);
  const vector = pick(VECTORS, id * 13 + 5);
  const stack = pick(STACKS, id * 17 + 11);
  return { id, topic, provider, vector, stack };
}

export function titleCase(s: string): string {
  return s.split(/[-_]/g).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}


type HubKind = "topic" | "provider" | "vector" | "stack";

function idxOf(kind: HubKind, slug: string): number {
  const map: Record<HubKind, string[]> = { topic: TOPICS, provider: PROVIDERS, vector: VECTORS, stack: STACKS };
  return map[kind].indexOf(slug);
}

/**
 * Deterministically generates IDs that share a dimension (topic/provider/vector/stack).
 * Uses modular arithmetic to keep it O(1) without scanning the whole corpus.
 */
export function relatedByDimension(kind: HubKind, slug: string, seed: number, count: number): number[] {
  const n = getRunbookCount();
  const sizes: Record<HubKind, number> = { topic: TOPICS.length, provider: PROVIDERS.length, vector: VECTORS.length, stack: STACKS.length };
  const size = sizes[kind];

  const index = idxOf(kind, slug);
  if (index < 0) return [];

  // The runbook slug generator uses these index functions:
  // topic: id % size
  // provider: (id * 7 + 3) % size
  // vector: (id * 13 + 5) % size  (13 ≡ 1 mod 12)
  // stack: (id * 17 + 11) % size  (17 ≡ 5 mod 12)
  // For our fixed arrays (size=12), these inverses hold:
  // inv7 mod12 = 7, inv5 mod12 = 5
  const mod = size;

  let residue = 0;
  if (kind === "topic") residue = ((index % mod) + mod) % mod;
  if (kind === "vector") residue = ((index - 5) % mod + mod) % mod; // id ≡ index-5 (mod 12)
  if (kind === "provider") residue = (((index - 3) * 7) % mod + mod) % mod; // id ≡ (index-3)*inv7
  if (kind === "stack") residue = (((index - 11) * 5) % mod + mod) % mod; // id ≡ (index-11)*inv5

  // Convert residue 0..mod-1 to a positive id base (avoid 0).
  const base = residue === 0 ? mod : residue;

  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    const k = (seed + i * 37) % Math.max(1, Math.floor(n / mod));
    const id = base + mod * k;
    out.push(((id - 1) % n) + 1);
  }
  // de-dup while preserving order
  return Array.from(new Set(out)).slice(0, count);
}
export function relatedRunbookIds(id: number): number[] {
  const n = getRunbookCount();
  return [1,2,3,4,5,6].map(k => Math.abs((id * (k+3) + k*97) % n));
}

export function buildRunbookContent(meta: { id: number, topic: string, provider: string, vector: string, stack: string }) {
  const { id, topic, provider, vector, stack } = meta;
  const topicT = titleCase(topic);
  const providerT = titleCase(provider);
  const vectorT = titleCase(vector);
  const stackT = titleCase(stack);

  // Deterministic “variation” so content is stable per URL but not copy-pasta.
  const v = (id * 9301 + 49297) % 233280;
  const variant = v % 6;

  const keyword = `OpenClaw ${topicT} on ${providerT} (${stackT}) — mitigate ${vectorT}`;
  const updated = new Date().toISOString().slice(0,10);

  const riskLines = [
    `Attackers typically reach ${vectorT} through exposed admin surfaces + weak runtime boundaries.`,
    `Most “RCE incidents” are configuration failures: public control plane, permissive tokens, wide egress.`,
    `Goal: make exploitation boring: shrink exposure, constrain execution, reduce blast radius.`,
  ];

  const providerLines = [
    `Map baseline controls to ${providerT}: firewall rules, private networking, IAM boundaries, audit logs.`,
    `Prefer private control-plane networking on ${providerT} over public endpoints.`,
    `Treat ${providerT} metadata endpoints as hostile targets: block or harden access.`,
  ];

  const stackLines = [
    `Harden ${stackT} defaults: patch cadence, minimal packages, locked services, least privilege runtime.`,
    `Pin dependencies and validate integrity (supply chain) to reduce silent compromise.`,
    `Enforce key-only access; rotate secrets; keep admin endpoints off the public internet.`,
  ];

  const vectorPlaybooks: Record<string, string[]> = {
    "ssrf": [
      "Default-deny egress; allowlist only required domains/IPs.",
      "Block cloud metadata IPs (e.g., 169.254.169.254) at host + container level.",
      "Log outbound destinations; alert on new autonomous egress patterns."
    ],
    "reverse-shell": [
      "Restrict outbound connections; most shells need egress to succeed.",
      "Alert on unexpected process spawning + outbound TCP to rare ports.",
      "Use sandboxing: seccomp/AppArmor + read-only FS where feasible."
    ],
    "path-traversal": [
      "Disable unsafe path joins; enforce allowlist directories for file reads.",
      "Run agents with minimal filesystem permissions; isolate work dirs.",
      "Monitor access to sensitive paths (/etc, ~/.ssh, tokens)."
    ],
    "deserialization": [
      "Disable unsafe deserializers; validate input types strictly.",
      "Separate untrusted parsing into low-privilege processes.",
      "Pin versions; watch CVEs; isolate plugins/extensions."
    ],
    "open-ports": [
      "Close everything. Expose only what you must, behind allowlists/VPN.",
      "Inventory ports continuously; fail deploys on unexpected listeners.",
      "Use security groups/firewalls as code, reviewed like production code."
    ],
    "config-drift": [
      "Drift kills security slowly. Use IaC + policy checks in CI.",
      "Daily diff: firewall rules, SSH settings, agent permissions, egress lists.",
      "Alert on changes outside change windows; rotate compromised credentials."
    ],
  };

  const vectorHints = vectorPlaybooks[vector] || [
    `Reduce the surface that enables ${vectorT}: private access, strict auth, hardened runtime.`,
    `Constrain egress, processes, and filesystem reachability to prevent escalation.`,
    `Instrument: alert on anomalies; isolate nodes quickly; redeploy from clean images.`
  ];

  const snippetsByStack: Record<string, string[]> = {
    "ufw": [
      "ufw default deny incoming",
      "ufw default deny outgoing",
      "ufw allow in from <YOUR_VPN_CIDR> to any port <CONTROL_PLANE_PORT>",
      "ufw enable"
    ],
    "iptables": [
      "iptables -P INPUT DROP",
      "iptables -P OUTPUT DROP",
      "iptables -A INPUT -s <YOUR_VPN_CIDR> -p tcp --dport <CONTROL_PLANE_PORT> -j ACCEPT",
      "iptables -A OUTPUT -d <ALLOWLIST_IP> -p tcp --dport 443 -j ACCEPT"
    ],
    "nftables": [
      "nft add table inet filter",
      "nft add chain inet filter input '{ type filter hook input priority 0; policy drop; }'",
      "nft add rule inet filter input ip saddr <YOUR_VPN_CIDR> tcp dport <CONTROL_PLANE_PORT> accept"
    ],
    "docker": [
      "docker run --read-only --cap-drop=ALL --security-opt no-new-privileges ...",
      "Use user namespaces; avoid mounting /var/run/docker.sock into agent containers."
    ],
    "kubernetes": [
      "Use NetworkPolicies: default-deny egress + ingress.",
      "Run agents with restricted ServiceAccounts; disable automountServiceAccountToken when possible."
    ],
  };

  const snippets = snippetsByStack[stack] || [
    "Disable public control plane exposure; gate via VPN/allowlist.",
    "Default-deny egress; explicitly allow required endpoints only.",
    "Run agents as non-root; read-only FS where feasible; drop capabilities."
  ];

  const checklistA = [
    "Control plane is NOT public (VPN / allowlist only).",
    "Agent runtime is sandboxed (FS/Proc/Net boundaries).",
    "Egress is restricted (explicit outbound allowlist).",
    "Dependencies pinned + integrity validated.",
  ];

  const checklistB = [
    "SSH: keys-only + MFA; disable password auth.",
    "Secrets: short-lived tokens; scope-limited permissions; rotation.",
    "Segmentation: isolate agent runners from control plane and data stores.",
    "Logging: alert on new outbound destinations, exec spikes, auth anomalies.",
  ];

  const sections = [
    {
      h: "Threat Model",
      bullets: variant < 3 ? riskLines : riskLines.slice().reverse(),
    },
    {
      h: "30-Second Audit Checklist",
      bullets: variant % 2 === 0 ? checklistA : checklistB,
    },
    {
      h: `Vector-Specific Hardening (${vectorT})`,
      bullets: vectorHints,
    },
    {
      h: `Provider Controls (${providerT})`,
      bullets: providerLines,
    },
    {
      h: `Hardening Actions (${stackT})`,
      bullets: stackLines,
    },
    {
      h: "Commands & Config Snippets",
      bullets: snippets.map((s) => `\`${s}\``),
    },
    {
      h: "Detection & Response",
      bullets: [
        "Alert on unexpected binary execution, new outbound destinations, privilege escalation attempts.",
        "Isolate compromised nodes; rotate credentials; redeploy from clean images.",
        "Post-incident diff: firewall rules, SSH settings, runtime perms, egress allowlists.",
      ],
    },
  ];

  return { keyword, updated, topicT, providerT, vectorT, stackT, sections };
}


export const GLOSSARY: Array<{ term: string; slug: string; short: string; long: string }> = [
  { term: "RCE (Remote Code Execution)", slug: "rce", short: "Execution of attacker-controlled code on your host.", long: "Remote Code Execution (RCE) is the class of vulnerabilities where an attacker can make a target system execute arbitrary code. In OpenClaw-style deployments, the path is often exposure + misconfiguration (public control plane, over-privileged runtime, permissive egress) rather than a single bug." },
  { term: "SSRF (Server-Side Request Forgery)", slug: "ssrf", short: "Forced outbound requests from your server to internal targets.", long: "SSRF is when an attacker causes your system to fetch URLs on their behalf. This can hit cloud metadata endpoints, internal admin panels, or private services. The practical defense is strict egress policies and metadata hardening." },
  { term: "Least Privilege", slug: "least-privilege", short: "Give agents the minimum permissions required.", long: "Least privilege reduces blast radius. Agents should run with minimal filesystem access, minimal network reachability, and tokens scoped to a single job. When compromised, they can’t pivot far." },
  { term: "Egress Filtering", slug: "egress-filtering", short: "Restrict outbound network traffic.", long: "Most real compromises get worse when the host can freely call out. Egress filtering blocks exfiltration, C2 beacons, and lateral movement. Default-deny outbound with explicit allowlists wins." },
  { term: "Control Plane", slug: "control-plane", short: "The management surface that configures/controls agents.", long: "Your control plane is the crown jewels. Do not expose it publicly. Put it behind a VPN, allowlist, or private network and enforce strong auth + logging." },
];

export type HubKind = "topic" | "provider" | "vector" | "stack";

export function kindLabel(kind: HubKind): string {
  switch (kind) {
    case "topic": return "Topic";
    case "provider": return "Provider";
    case "vector": return "Attack Vector";
    case "stack": return "Stack";
  }
}

export function comparePairs(): Array<{ slug: string; a: string; b: string; kind: "provider" | "stack" }> {
  // Keep this list bounded for sitemaps; pages still work dynamically for any slug.
  const pairs: Array<{ slug: string; a: string; b: string; kind: "provider" | "stack" }> = [];
  for (let i = 0; i < PROVIDERS.length; i++) {
    for (let j = i + 1; j < PROVIDERS.length; j++) {
      const a = PROVIDERS[i], b = PROVIDERS[j];
      pairs.push({ slug: `${a}-vs-${b}`, a, b, kind: "provider" });
    }
  }
  for (let i = 0; i < STACKS.length; i++) {
    for (let j = i + 1; j < STACKS.length; j++) {
      const a = STACKS[i], b = STACKS[j];
      pairs.push({ slug: `${a}-vs-${b}`, a, b, kind: "stack" });
    }
  }
  return pairs.slice(0, 500);
}
