import crypto from "crypto";
import { getBlobStore } from "./blobStore";

export type RateTier = "free" | "daypass" | "pro" | "team";

const DEFAULT_LIMITS: Record<RateTier, { windowSeconds: number; max: number }> = {
  free: { windowSeconds: 24 * 3600, max: 0 },
  daypass: { windowSeconds: 24 * 3600, max: 25 },
  pro: { windowSeconds: 24 * 3600, max: 250 },
  team: { windowSeconds: 24 * 3600, max: 1200 },
};

function sha(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

function parseLimitsFromEnv(): Record<RateTier, { windowSeconds: number; max: number }> {
  // Allow overrides:
  // AI_LIMIT_DAYPASS=25, AI_LIMIT_PRO=250, AI_LIMIT_TEAM=1200, AI_LIMIT_WINDOW_SECONDS=86400
  const windowSeconds = Math.max(60, Number(process.env.AI_LIMIT_WINDOW_SECONDS || DEFAULT_LIMITS.pro.windowSeconds));
  const daypass = Math.max(0, Number(process.env.AI_LIMIT_DAYPASS || DEFAULT_LIMITS.daypass.max));
  const pro = Math.max(0, Number(process.env.AI_LIMIT_PRO || DEFAULT_LIMITS.pro.max));
  const team = Math.max(0, Number(process.env.AI_LIMIT_TEAM || DEFAULT_LIMITS.team.max));
  return {
    free: { windowSeconds, max: 0 },
    daypass: { windowSeconds, max: daypass },
    pro: { windowSeconds, max: pro },
    team: { windowSeconds, max: team },
  };
}

type RateState = { windowStart: number; count: number; tier: RateTier };

export async function checkAndBumpRateLimit(opts: {
  key: string; // user identifier (ip or user id)
  tier: RateTier;
}): Promise<{ allowed: true; remaining: number; resetSeconds: number } | { allowed: false; remaining: 0; resetSeconds: number }> {
  const limits = parseLimitsFromEnv();
  const limit = limits[opts.tier];

  // Free tier disabled by default (max=0)
  if (limit.max <= 0) {
    return { allowed: false, remaining: 0, resetSeconds: limit.windowSeconds };
  }

  const store = getBlobStore("clawguru-ratelimits");
  const bucket = Math.floor(nowSec() / limit.windowSeconds);
  const k = `ai:${opts.tier}:${bucket}:${sha(opts.key)}`;

  const state = (await store.get(k, { type: "json" }).catch(() => null)) as RateState | null;
  const current: RateState = state ?? { windowStart: bucket * limit.windowSeconds, count: 0, tier: opts.tier };

  const nextCount = current.count + 1;
  const resetSeconds = current.windowStart + limit.windowSeconds - nowSec();

  if (nextCount > limit.max) {
    return { allowed: false, remaining: 0, resetSeconds: Math.max(1, resetSeconds) };
  }

  await store.setJSON(k, { ...current, count: nextCount });

  return { allowed: true, remaining: Math.max(0, limit.max - nextCount), resetSeconds: Math.max(1, resetSeconds) };
}
