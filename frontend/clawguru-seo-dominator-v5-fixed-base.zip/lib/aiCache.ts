import crypto from "crypto";
import { getBlobStore } from "./blobStore";

function sha(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

const DEFAULT_TTL = 6 * 3600; // 6h

export type CacheGetResult = { hit: true; text: string } | { hit: false };

export async function getCachedAIResponse(opts: {
  provider: string;
  model: string;
  system?: string;
  prompt: string;
}): Promise<CacheGetResult> {
  const ttl = Math.max(60, Number(process.env.AI_CACHE_TTL_SECONDS || DEFAULT_TTL));
  if (ttl <= 0) return { hit: false };

  const store = getBlobStore("clawguru-ai-cache");
  const key = `v1:${opts.provider}:${opts.model}:${sha((opts.system || "") + "\n" + opts.prompt)}`;

  const data = (await store.get(key, { type: "json" }).catch(() => null)) as null | { text: string; ts: number };
  if (!data?.text || !data?.ts) return { hit: false };

  const age = Math.floor(Date.now() / 1000) - data.ts;
  if (age > ttl) return { hit: false };

  return { hit: true, text: data.text };
}

export async function setCachedAIResponse(opts: {
  provider: string;
  model: string;
  system?: string;
  prompt: string;
  text: string;
}): Promise<void> {
  const ttl = Math.max(60, Number(process.env.AI_CACHE_TTL_SECONDS || DEFAULT_TTL));
  if (ttl <= 0) return;

  const store = getBlobStore("clawguru-ai-cache");
  const key = `v1:${opts.provider}:${opts.model}:${sha((opts.system || "") + "\n" + opts.prompt)}`;
  await store.setJSON(key, { text: opts.text, ts: Math.floor(Date.now() / 1000) });
}
