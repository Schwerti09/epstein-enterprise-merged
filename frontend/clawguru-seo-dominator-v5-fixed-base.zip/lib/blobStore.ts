import { getStore, getDeployStore } from "@netlify/blobs";

/**
 * Choose a safe Blob store:
 * - production -> global store (shared across deploys)
 * - previews/dev -> deploy store (keeps test data isolated)
 */
export function getBlobStore(name: string) {
  const deployContext = (globalThis as any)?.Netlify?.context?.deploy?.context;
  if (deployContext === "production") return getStore(name);
  return getDeployStore(name);
}
